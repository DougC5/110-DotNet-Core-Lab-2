using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Restaurant.Models;

namespace Restaurant.Controllers
{
    public class DishController: Controller
    {
        // Create Get method for Create Action -> View()
        public IActionResult Create()
        {
            return View();
        }
        // Create View Page inside Dish Folder *DONE*
        // Create Menu Item *DONE*
        // Create Model for Dish *DONE*
            // name, price, img, Description, Vegan(Bool)

        // Do validations: Name and double value/ Do not send data to server "return;"

        // Create capture form on view
        // define HTTP Post for create
        // Send Data to server

        [HttpPost]
        public string Register([FromBody] Dish newDish)
        {
            Console.WriteLine("***********************");
            Console.WriteLine("Creating " + newDish.Name);
            Console.WriteLine("Creating " + newDish.Price);
            Console.WriteLine("Creating " + newDish.Vegan);
            Console.WriteLine("***********************");
            return "OK";
        }

    }
}