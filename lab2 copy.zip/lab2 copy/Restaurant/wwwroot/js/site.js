﻿// Please see documentation at https://docs.microsoft.com/aspnet/core/client-side/bundling-and-minification
// for details on configuring this project to bundle and minify static web assets.

// Write your JavaScript code.

// $('#errorAlert').hide();


function clicked() {
    console.log('button was clicked');
    
}

function RegisterDishInfo(){
    let name = $('#dishName').val();
    let price = $('#dishPrice').val();
    let image = $('#dishImg').val();
    let description = $('#dishDescription').val();
    let vegan = $("#isVegan").is(":checked");

    $("#dishName, #dishPrice").removeClass( "border border-danger" );

    // Do Validations

    if (name === "") {   	
        $( "#dishName" ).addClass( "border border-danger" );
        $('#dishName').attr("placeholder","Please Enter a Name");
        $('#errorAlert').show();
        return;
    }

    if (price < 0 || isNaN(price) || price === '') {
        $('#dishPrice').val('');
        $( "#dishPrice" ).addClass( "border border-danger" );
        $('#dishPrice').attr("placeholder","Please enter a valid number");
        $('#errorAlert').show();
        return;
    }

    let dish = {
        Id: 1,
        Name: name,
        Price: price,
        Image: image,
        Description: description,
        Vegan: vegan
    };

    console.log("Sending Dish to server");

    $.ajax({
        type: "POST",
        url: "/Dish/Register",
        data: JSON.stringify(dish),
        contentType: "application/json; charset=utf-8",
        success: function (res) {
            console.log('Dish POST Ended');
            console.log('Server Says: ', res);

            // Clear Inputs
            $('#dishName').val('');
            $('#dishPrice').val('');
            $('#dishImg').val('');
            $('#dishDescription').val('');
            $("#isVegan").prop( "checked", false );

            // Reset error fields
            $("#errorAlert").hide();
            $("#dishName, #dishPrice").removeClass( "border border-danger" );
            $("#dishName, #dishPrice").removeAttr("placeholder");
            
        }
    });
}



function SendTest(){
    let fName = $('#txtFirstName').val();
    let lName = $('#txtLastName').val();
    let phNum = $('#txtPhNumber').val();
    let pos = $('#txtPosition').val();
    let sal = $('#txtSalary').val();

    let emp = {
        Id: 1,
        Name: fName,
        LastName: lName,
        PhoneNumber: phNum,
        Position: pos,
        Salary: sal
    }

    console.log("Sending Employee to server");

    $.ajax({
        type: "POST",
        url: "/Employee/Create",
        data: JSON.stringify(emp),
        contentType: "application/json; charset=utf-8",
        success: function (res) {
            console.log('Employee POST Ended');
            console.log('Server Says: ', res);

            $('#txtFirstName').val('');
            $('#txtLastName').val('');
            $('#txtPhNumber').val('');
            $('#txtPosition').val('');
            $('#txtSalary').val('');
            
        }
    });
}
